#pragma once

#define HTTP_SERVER "5.188.35.89"
#define HTTP_PORT 80

#define TFTP_SERVER "5.188.35.89"
